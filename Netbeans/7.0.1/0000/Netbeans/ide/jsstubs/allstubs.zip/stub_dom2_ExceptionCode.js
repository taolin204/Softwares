var ExceptionCode = {
  // This is just a stub for a builtin native JavaScript object.
};

